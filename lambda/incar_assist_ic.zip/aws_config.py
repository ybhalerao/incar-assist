#config file containing AWS
data_bucket = "data-daizika-com"
base_data_location = "incar_assist/data"
base_model_location = "incar_assist/model"
intent_classification_model = "roberta-student-distilled"
